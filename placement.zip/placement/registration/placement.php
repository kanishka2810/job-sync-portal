<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $server='localhost';
    $username='root';
    $password="";
    $database="database";
    $con=mysqli_connect($server,$username,$password,$database);

    // if(!$con){
    //    die("connection failed due to ".mysqli_connect_error());
    // }
    // else{
    //     echo "connection successful";
    // }
    $n1=$_POST['P_Name'];
    $n3=$_POST['p_Email'];
    $p_password=$_POST['p_Password'];
    $p_deg=$_POST['deg'];
    $p_id=$_POST['id'];

    $sql="INSERT INTO placement ( p_name,p_email,p_password,id,deg) VALUES 
    ( '$n1', '$n3', '$p_password','$p_id','$p_deg')";

if ($con->query($sql) == true) {
    // Redirect to student_login.html
    header("Location:../login/placement_login.html");
    exit(); // Make sure to exit after redirection
} else {
    echo "Error: $sql <br> $con->error";
}

    $con->close();
}

?>