<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $_SERVER='localhost';
    $username='root';
    $password="";
    $database="database";
    
    $con=mysqli_connect($_SERVER,$username,$password,$database);

    if(!$con){
       die("connection failed due to ".mysqli_connect_error());
    }
    else{
        echo "connection successful";
    }
    $name=$_POST['Name'];
    $email=$_POST['Email'];
    $id=$_POST['id'];
    $Phone=$_POST['Phone'];
    $fathername=$_POST['Father'];
    $password=$_POST['Password'];
    $course=$_POST['Course'];
    $sql="INSERT INTO users ( user_name, u_email, id, u_phone, u_father, u_course, u_password) VALUES 
    ( '$name', '$email', '$id', '$Phone', '$fathername','$course', '$password');";

    if ($con->query($sql) == true) {
        // Redirect to student_login.html
        header("Location:../login/student_login.html");
        exit(); // Make sure to exit after redirection
    } else {
        echo "Error: $sql <br> $con->error";
    }
    // if($con ->query($sql) == true){
    //     echo "successfully inserted";
    // }
    // else{
    //     echo "Error : $sql <br> $con-> error";
    // }

    $con->close();
}

?>