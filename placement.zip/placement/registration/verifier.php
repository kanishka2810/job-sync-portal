<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $_SERVER='localhost';
    $username='root';
    $password="";
    $database="database";
    
    $con=mysqli_connect($_SERVER,$username,$password,$database);

    if($con){
    //    die("connection failed due to ".mysqli_connect_error());
    // }
    // else{
        echo "connection successful";
    }
    $n2=$_POST['v_Name'];
    $v_email=$_POST['v_Email'];
    $v_password=$_POST['v_Password'];

    $sql="INSERT INTO hod ( s_name, s_email,s_password) VALUES 
    ( '$n2', '$v_email', '$v_password');";

if ($con->query($sql) == true) {
    // Redirect to student_login.html
    header("Location:../login/verifier_login.html");
    exit(); // Make sure to exit after redirection
} else {
    echo "Error: $sql <br> $con->error";
}
    $con->close();
}

?>