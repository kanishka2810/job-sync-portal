<?php

session_start();

    $server='localhost';
    $username='root';
    $password="";
    $database="database";
    
    $con=mysqli_connect($server,$username,$password,$database);

    if(!$con){
       die("connection failed due to ".mysqli_connect_error());
    }
    // else{
    //     echo "connection successful";
    // }
    
    //echo $_SESSION['myValue'];
//     if (!empty($_SESSION['myValue']))
//  {
//     echo $_SESSION['myValue'];
// }
// else
// {
//     echo "Session not set yet.";
// }
$pid= $_SESSION['myValue'];
    $sql="SELECT * From `placement` WHERE id={$pid}";
    $result=mysqli_query($con,$sql);
    //find the number return
    
    // $num=mysqli_num_rows($result);
    // echo $num;
    // echo "<br>";
   
    // if($num>0){
    //     $row=mysqli_fetch_assoc($result);
    //     echo var_dump($row);
    //     echo "<br>";
    //     $row=mysqli_fetch_assoc($result);
    //     echo var_dump($row);
    //     echo "<br>";
    // }
    // if ($num > 0) {
        $userData = [];

        // Fetch and store user data
        while ($row = mysqli_fetch_assoc($result)) {
            $userData[] = $row;
        }
// Close the database connection
mysqli_close($con);
// echo '<pre>';
 //var_dump($userData);
// echo '</pre>';

// Define a constant to store the fetched data



        // while ($row = mysqli_fetch_assoc($result)) {
        //     echo $row['id'] . " hello " . $row['user_name'] . " your email is " . $row['u_email'] . " your domain is " . $row['u_course'] . " phone no: " . $row['u_phone'];
        //     echo "<br>";
        // }
    // } else {
    //     echo "No rows found in the database.";
    // }
    //update
    // $sql="UPDATE `users` SET `user_name`='palak' WHERE   `u_course`='MCA'";
    // $result=mysqli_query($con,$sql);
    // if($result){
    //     echo "we update";
    // }
    // else{
    //     echo "we could not";
    // }
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Banasthali Vidyapith</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="assets/css/feather.css" rel="stylesheet" type="text/css">
  <script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>

<style>
    ul
{ 
width: 100%;
} 

li
{ 
    margin-right: 5%;
display:inline; 
font-size: 18px;
font-weight: 600;
}  
</style>

</head>
<body style="background-color: #efeff0;">
    <div class="container-fluid" id="nav-bar" style="background-color: #4b5fcb; width:100%">
        <div class="row">
            <div class="col-lg-4">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="image" style="align-items: end; text-align: center;">
                            <img _ngcontent-hsa-c79="" src="../image/logo.png" alt="BV logo" height="50" class="mr-3">
                        </div>

                    </div>
                    <div class="col-lg-7">
                        <div class="col_name">
                            <h1 style="color: white; margin-top: 7%; font-size: 20px;">JobSync Portal</h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8" style="align-items: end; text-align: end; margin-top: 1%;">
                <ul style="list-style: none;">
                    <li>
                        <a href="#Contact Us" style="text-decoration: none; color: white;">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid" id="detail" style=" background-color: white; height: 90vh;">
        <div class="row">
            <div class="col-lg-2" style="border-right: 1px solid black; padding-top: 2%; height: 91vh; background-color: white;">
                <a href="profile.php" style="color: black; text-decoration: none; font-weight: 600;">
                <div class="container" style="border: 1px solid white; align-items: center; text-align: center; padding-top: 3%; height: 7%;  background-color: rgb(218, 210, 210); box-shadow: 3px 5px #888888;">
                    <p style="vertical-align: middle;">
                        Profile
                    </p>
                </div>
                </a>
            <a href="btech_company.html" style="color: black; text-decoration: none; font-weight: 600;">
                <div class="container" style="border: 1px solid white; align-items: center; text-align: center; padding-top: 3%; height: 7%;  background-color: rgb(218, 210, 210); box-shadow: 3px 5px #888888; margin-top: 5%;">
                    <p style="vertical-align: middle;">
                        Company Details
                    </p>
                </div>
            </a>
            <a href="btech_student_detail.html" style="color: black; text-decoration: none; font-weight: 600; ">
                <div class="container" style="border: 1px solid white; align-items: center; text-align: center; padding-top: 3%; height: 7%;  background-color: rgb(218, 210, 210); box-shadow: 3px 5px #888888; margin-top: 5%;">
                    <p style="vertical-align: middle;">
                        Student Details
                    </p>
                </div>
            </a>
            <a href="study_material.html" style="color: black; text-decoration: none; font-weight: 600; ">
                <div class="container" style="border: 1px solid white; align-items: center; text-align: center; padding-top: 3%; height: 7%;  background-color: rgb(218, 210, 210); box-shadow: 3px 5px #888888; margin-top: 5%;">
                    <p style="vertical-align: middle;">
                        Study Material
                    </p>
                </div>
            </a>
            <a href="btech_placement.html" style="color: black; text-decoration: none; font-size: 15px; font-weight: 600; ">
              <div class="container" style="border: 1px solid white; align-items: center; text-align: center; padding-top: 3%; height: 7%;  background-color: rgb(218, 210, 210); box-shadow: 3px 5px #888888; margin-top: 5%;">
                  <p style="vertical-align: middle; ">
                      Previous Year Placements
                  </p>
              </div>
          </a>
            </div> 
             <div class="col-lg-10" style="padding-top: 2%;">
             <form action="profile2.php" method="post">
    <textarea name="textarea1" id="textarea1" rows="10" cols="50">
    
        <?php
// Assuming $userData is already populated with data
// Iterate through each element in $userData array
foreach ($userData as $user) {
    // Check if 'u_course' key exists in the current user data
    if (isset($user['id'])) {
        // Echo the value of 'u_course'
        
       
        
        // You can access other keys in a similar manner
        // For example:
        echo "ID=".$user['id']. "\n"; ;
       
        echo "Name= ". $user['p_name']. "\n"; ;
       
        echo "Email= ".$user['p_email']. "\n"; ;
       
//echo"Contact= ".$user['u_phone']. "\n"; ;
        echo "Designation=".$user['deg']. "\n"; ;
       
         
    }
}
?>
    </textarea><br /> 
    <input type="submit" value="submit" />
     </form>
                <!--<div class="container">
                    <div class="row">
                        <div class="col-lg-6" style="align-items: start;">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <h6 style="margin-top: 5%;">Name</h6>
                                    </div>
                                    <div class="col-lg-8">
                                        <div class="container" style="border: 1px solid black; margin-left: -22%;">
                                            <p style="height: 20px;">Kanishka</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <h6 style="margin-top: 5%;">Contact</h6>
                                    </div>
                                    <div class="col-lg-8">
                                        <div class="container" style="border: 1px solid black; margin-left: -22%;">
                                            <p style="height: 20px;">7878031621</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row" style="margin-top: 3%;">
                        <div class="col-lg-6">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <h6 style="margin-top: 5%;">Email id</h6>
                                    </div>
                                    <div class="col-lg-8">
                                        <div class="container" style="border: 1px solid black; margin-left: -22%;">
                                            <p style="height: 20px;">kanishka@gmail.com</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <h6 style="margin-top: 5%;">ID</h6>
                                    </div>
                                    <div class="col-lg-8">
                                        <div class="container" style="border: 1px solid black; margin-left: -22%;">
                                            <p style="height: 20px;">21</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row" style="margin-top: 3%;">
                        <div class="col-lg-6">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <h6 style="margin-top: 5%;">Designation</h6>
                                    </div>
                                    <div class="col-lg-8">
                                        <div class="container" style="border: 1px solid black; margin-left: -22%;">
                                            <p style="height: 20px;">Placemtent Cell Head</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row" style="margin-top: 6%;">
                        <div class="col-lg-6"></div>
                        <div class="col-lg-3"  style="border: 1px solid black; align-items: center; text-align: center; width: 170px; margin-right: 10px; background-color: blue;">
                            <a href="company.html" style="text-decoration: none; font-weight: 600; font-size: 20px; color: white;">Okay</a>
                        </div>
                        <div class="col-lg-3" style="border: 1px solid black; align-items: center; text-align: center;  width: 170px; background-color: blue;">
                            <a href="edit_profile.html" style="text-decoration: none; font-weight: 600; font-size: 20px; color: white;">Edit</a>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>