<?php
session_start();
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $_SERVER='localhost';
    $username='root';
    $password="";
    $database="database";
    
    $con=mysqli_connect($_SERVER,$username,$password,$database);

    if(!$con){
       die("connection failed due to ".mysqli_connect_error());
    }
    // else{
    //     echo "connection successful 1000";
    // }
    $u_name=$_POST['Name'];
    $u_email=$_POST['Email'];
    $u_message=$_POST['Message'];
    $u_subject=$_POST['Subject'];
    
    $sql="INSERT INTO feedback ( f_name, email, f_message,f_subject) VALUES
    ( '$u_name', '$u_email', '$u_message','$u_subject');";
    

    // if ($con->query($sql) == true) {
    //     // Redirect to student_login.html
    //     header("Location:../login/student_login.html");
    //     exit(); // Make sure to exit after redirection
    // } else {
    //     echo "Error: $sql <br> $con->error";
    // }
    if($con ->query($sql) == true){
        //echo "successfully inserted";
        header("Location:index.php");
    }
    else{
        echo "Error : $sql <br> $con-> error";
    }

    $con->close();
}

?>