<?php


session_start();
if($_SERVER["REQUEST_METHOD"]=="POST"){
    $server='localhost';
    $username='root';
    $password="";
    $database="database";
    
    $con=mysqli_connect($server,$username,$password,$database);

    if(!$con){
       die("connection failed due to ".mysqli_connect_error());
    }
    else{
        echo "connection successful";
    }
    
    $id=$_POST["id"];
    $password=$_POST["Password"];
    $Course=$_POST["Course"];

    // Prepare SQL statement to select user password and course
    $sql = "SELECT u_password, u_course FROM users WHERE id=? AND u_course=?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("ss", $id, $Course);

    // Execute the prepared statement
    $stmt->execute();

    // Store result
    $stmt->store_result();

    // Check if username exists and the course is correct
    if ($stmt->num_rows == 1) {
        // Bind result variables
        $stmt->bind_result($hashed_password, $u_course);
        $stmt->fetch();
        $_SESSION['myValue']=$id;
        
        if ($u_course == "MCA") {
            // Redirect to MCA profile
            $_SESSION['logged_in'] = true;
            header("Location:../mca/index.php");
            exit();
        } elseif ($u_course == "B.tech") {
            // Redirect to B.Tech profile
            $_SESSION['logged_in'] = true;
            header("Location:../btech/index1.php");
            exit();
        } else {
            // Handle other courses or invalid values
            echo "Invalid course or profile not found.";
        }
    } else {
        echo "Invalid user ID or course.";
    }

    // Close statement and connection
    $stmt->close();
    $con->close();
     // You can set the value however you like.
    
}
?>
