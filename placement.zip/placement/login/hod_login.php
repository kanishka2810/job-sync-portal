<?php
session_start();
if($_SERVER["REQUEST_METHOD"]=="POST"){
    $_SERVER='localhost';
    $username='root';
    $password="";
    $database="database";
    
    $con=mysqli_connect($_SERVER,$username,$password,$database);

    if(!$con){
       die("connection failed due to ".mysqli_connect_error());
    }
    else{
        echo "connection successful";
    }
$id=$_POST["id"];
$password=$_POST["Password"];
$sql="Select * from hod where id='$id' AND s_password='$password'";
$result=mysqli_query($con,$sql);
$num=mysqli_num_rows($result);
if($num==1)
{   $_SESSION['logged_in'] = true;
     $_SESSION['myValue']=$id;
    header("Location:../verifier(HOD)/fetch.php");
}
else{
    echo "Error: $sql <br> $con->error";
}
if (isset($_SESSION['Password'])) {
    // Clear the session variable
    unset($_SESSION['Password']);
}

// if (isset($_SESSION['myValue'])) {
//     unset($_SESSION['myValue']); // Unset the session variable associated with the ID
// }



}
?>
