<?php
session_start();
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $_SERVER='localhost';
        $username='root';
        $password="";
        $database="database";
        
        $con=mysqli_connect($_SERVER,$username,$password,$database);
    
        if(!$con){
           die("connection failed due to ".mysqli_connect_error());
        }
        else{
            echo "connection successful";
        }
$id=$_POST["id"];
$password=$_POST["Password"];
$sql="Select * from placement where id='$id' AND p_password='$password'";
$result=mysqli_query($con,$sql);
$num=mysqli_num_rows($result);
if($num==1)
{   $_SESSION['myValue']=$id;
    header("Location:../placement_cell/profile.php");
}
else{
    echo "Error: $sql <br> $con->error";
}

}

?>
