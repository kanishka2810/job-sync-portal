<?php
session_start();

$server='localhost';
$username='root';
$password="";
$database="database";

$con=mysqli_connect($server,$username,$password,$database);

if(!$con){
   die("connection failed due to ".mysqli_connect_error());
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = validate_input($_POST['name']);
    $email = validate_input($_POST['email']);
    $contact = validate_input($_POST['contact']);
    $father = validate_input($_POST['father']);
    $course = validate_input($_POST['course']);
    $id = validate_input($_POST['id']);

    // If any field is empty, display an error message
    if (empty($name) || empty($contact) || empty($email) || empty($id)||empty($father)||empty($course)) {
        echo "All fields are required.";
    } elseif (!filter_var($id, FILTER_VALIDATE_INT)) {
        echo "ID must be a valid integer.";
    } else {
    $update_query = "UPDATE `users` SET `user_name`='$name', `u_phone`='$contact', `u_email`='$email' ,`u_father`='$father',`u_course`='$course' WHERE `id`='$id'";

    // Execute the update query
    if (mysqli_query($con, $update_query)) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . mysqli_error($con);
    }
}
}
function validate_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
// Fetch session value
echo $_SESSION['myValue'];
$uid = $_SESSION['myValue'];
if (!isset($_SESSION['myValue'])) {
    // Redirect to login page if session variable is not set
    header("Location: ../login/verifier_login.html");
    exit;
}

// Select query
$sql="SELECT * FROM `users` WHERE id={$uid}";
$result=mysqli_query($con,$sql);
$userData = [];

// Fetch and store user data
while ($row = mysqli_fetch_assoc($result)) {
    $userData[] = $row;
}
if (isset($_POST['Home'])) {
    // Unset or destroy session variables
    session_unset();
    
    // Redirect back to page 1 after logout
    header("Location:index1.php");
    exit;
}

// Close the database connection
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>JobEntry - Job Portal Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid bg-white p-0">
        <!-- Navbar Start -->
        <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
            <a href="index.html" class="navbar-brand d-flex align-items-center text-center py-0 px-4 px-lg-5">
                <h1 class="m-0 text-primary">Job</h1>
                <h1 class="m-0 text" style="color: rgb(90, 90, 233);">Sync</h1>

            </a>
            <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse"
                data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto p-4 p-lg-0">
                    <form method="post" action="">
                  <button type="submit" name="Home"  class="nav-item nav-link active">home</button>
                        </form>
                    <!-- <a href="index.html" class="nav-item nav-link">Companies</a>
                    <a href="index.html" class="nav-item nav-link">Students</a>
                    <a href="index.html" class="nav-item nav-link">Placement Team</a>
                    <a href="index.html" class="nav-item nav-link">Contact</a>
                    <a href="index.html" class="nav-item nav-link">Logout</a> -->

                </div>

            </div>
        </nav>
        <!-- Navbar End -->

        <div class="container" style="margin-top: 4%;">
        <form method="post" action="">
                <div class="row">
                    <div class="col-lg-6" style="align-items: start;">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-4">
                                    <h6 style="margin-top: 5%;">Name</h6>
                                </div>
                                <div class="col-lg-8">
                                    <div class="container" style=" margin-left: -22%;">
                                        <input type="text" name="name" style="height: 40px; width: 300px; margin-left: -12px;"value="<?php echo $userData[0]['user_name']; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-4">
                                    <h6 style="margin-top: 5%;">Contact</h6>
                                </div>
                                <div class="col-lg-8">
                                    <div class="container" style=" margin-left: -22%;">
                                        <input type="tel" name="contact" style="height: 40px; width: 300px; margin-left: -12px;"value="<?php echo $userData[0]['u_phone']; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row" style="margin-top: 3%;">
                    <div class="col-lg-6">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-4">
                                    <h6 style="margin-top: 5%; margin-left: -15px;">Father's Name</h6>
                                </div>
                                <div class="col-lg-8">
                                    <div class="container" style=" margin-left: -22%;">
                                        <input type="text" name="father"style="height: 40px; width: 300px; margin-left: -12px;"value="<?php echo $userData[0]['u_father']; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-4">
                                    <h6 style="margin-top: 5%;">Roll No.</h6>
                                </div>
                                <div class="col-lg-8">
                                    <div class="container" style=" margin-left: -22%;">
                                        <input type="text" name="id" style="height: 40px; width: 300px; margin-left: -12px;"value="<?php echo $userData[0]['id']; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row" style="margin-top: 3%;">
                    <div class="col-lg-6">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-4">
                                    <h6 style="margin-top: 5%;">Email id</h6>
                                </div>
                                <div class="col-lg-8">
                                    <div class="container" style=" margin-left: -22%;">
                                        <input type="email" name="email" style="height: 40px; width: 300px; margin-left: -12px;"value="<?php echo $userData[0]['u_email']; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-4">
                                    <!-- <h6 style="margin-top: 5%;">Degree</h6>
                                </div>
                                <div class="col-lg-8">
                                    <div class="container" style=" margin-left: -22%;">
                                        <input type="text" style="height: 40px; width: 300px; margin-left: -12px;">
                                    </div>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row" style="margin-top: 3%;">
                    <div class="col-lg-6">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-4">
                                    <h6 style="margin-top: 5%;">Domain</h6>
                                </div>
                                <div class="col-lg-8">
                                    <div class="container" style=" margin-left: -22%;">
                                        <input type="text" name="course" style="height: 40px; width: 300px; margin-left: -12px;"value="<?php echo $userData[0]['u_course']; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row" style="margin-top: 4%; margin-bottom: 4%;">
                    <div class="col-lg-9"></div>
                    <div class="col-lg-3"  style=" align-items: center; text-align: center; width: 170px; margin-right: 10px; padding-bottom: 5px;">
                        <a href="company.html" ><button style="text-decoration: none; font-weight: 600; font-size: 20px; background-color: #00B074; border: 3px solid rgb(117, 117, 241); color: white; width: 160px;">Save</button></a>
                    </div>
                    
                </div>
            </form>
        </div>
        <!-- Footer Start -->
        <div class="container-fluid bg-dark text-white-50 footer wow fadeIn" data-wow-delay="0.1s">

            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-6 col-lg-6 text-center">
                            &copy; <a class="border-bottom" href="#">JobSync Portal</a>, All Right Reserved.

                            <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                            Designed By <a class="border-bottom" href="">Banasthali Vidyapith</a>
                        </div>
                        <div class="col-lg-6">
                            <div class="container" style="justify-content: flex-end; display: flex; ">
                                <ul style="display: flex; list-style: none;">
                                    <li>
                                        <a class="btn btn-outline-light btn-social" href=""><i
                                                class="fab fa-twitter"></i></a>
                                    </li>
                                    <li>
                                        <a class="btn btn-outline-light btn-social" href=""><i
                                                class="fab fa-facebook-f"></i></a>
                                    </li>
                                    <li>
                                        <a class="btn btn-outline-light btn-social" href=""><i
                                                class="fab fa-youtube"></i></a>
                                    </li>
                                    <li>
                                        <a class="btn btn-outline-light btn-social" href=""><i
                                                class="fab fa-linkedin-in"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->


        <!-- Back to Top -->
        
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>